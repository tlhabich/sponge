This is a minimal cost method to test the pneumatic seals of the lower frame.

Files:
1- Pneumatic_Seal_TestDisk: Test assembly
2- Pneumatic_Seal_TestDisk_Body: this file is a cut lower frame with all the necessary seals
3- Bellow_Sealer: the closed part of the bellow, where air would come through
4- valve_interface_Sealer: a closed valve interface